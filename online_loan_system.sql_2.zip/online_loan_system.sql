--
-- Database: `online_loan_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_personal_information`
--

CREATE TABLE `customer_personal_information` (
  `Cus_Name` varchar(30) NOT NULL,
  `Cus_ID` int(30) NOT NULL,
  `Contact_No` varchar(30) NOT NULL,
  `Present_Address` varchar(30) NOT NULL,
  `Permanent_Address` varchar(40) NOT NULL,
  `Guarantor_Name` varchar(30) NOT NULL,
  `Guarantor_No` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loan_application_information`
--

CREATE TABLE `loan_application_information` (
  `Cus_Id` varchar(30) NOT NULL,
  `loan_Amount` varchar(30) NOT NULL,
  `Payable_Amount` varchar(30) NOT NULL,
  `Monthly_Payment_Amount` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loan_information`
--

CREATE TABLE `loan_information` (
  `Loan_Type` varchar(50) NOT NULL,
  `Interest` varchar(5) NOT NULL,
  `Age_Limitation` varchar(30) NOT NULL,
  `Time_Duration` varchar(15) NOT NULL,
  `Max_Recieve_Amount` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan_information`
--

INSERT INTO `loan_information` (`Loan_Type`, `Interest`, `Age_Limitation`, `Time_Duration`, `Max_Recieve_Amount`) VALUES
('mariage', '25', '25', '5', '10000');

-- --------------------------------------------------------

--
-- Table structure for table `payment_information`
--

CREATE TABLE `payment_information` (
  `Cus_Id` varchar(30) NOT NULL,
  `Month` varchar(30) NOT NULL,
  `Amount` varchar(30) NOT NULL,
  `Due_Amount` varchar(30) NOT NULL,
  `Due_Month` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_personal_information`
--
ALTER TABLE `customer_personal_information`
  ADD PRIMARY KEY (`Cus_ID`);

--
-- Indexes for table `loan_application_information`
--
ALTER TABLE `loan_application_information`
  ADD PRIMARY KEY (`Cus_Id`);

--
-- Indexes for table `loan_information`
--
ALTER TABLE `loan_information`
  ADD PRIMARY KEY (`Loan_Type`);

--
-- Indexes for table `payment_information`
--
ALTER TABLE `payment_information`
  ADD PRIMARY KEY (`Cus_Id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
